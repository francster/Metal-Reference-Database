package com.example.franc.metalsreference;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class MetalsList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_metals_list);

        //getting the toolbar
        Toolbar toolbar =(Toolbar) findViewById(R.id.toolbarMetalList);

        //setting the title
        toolbar.setTitle("List of Metals");

        setSupportActionBar(toolbar);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.menuHome:
                //Toast.makeText(this,"You clicked Home",Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, Home.class));
                break;

            case R.id.menuHeatTreat:
                startActivity(new Intent(this, HeatTreatments.class));
                break;

            case R.id.menuMetals:
                //Toast.makeText(this,"You clicked List of Metals",Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, MetalsList.class));
                break;

            case R.id.menuContact:
                //Toast.makeText(this,"You clicked Contact Us",Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, ContactPage.class));
                break;

            case R.id.menuLogout:
                Toast.makeText(this, "You clicked Logout", Toast.LENGTH_SHORT).show();
                break;
        }
        return true;
    }
}
