package com.example.franc.metalsreference;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    FirebaseAuth mAuth;
    EditText l_email_field, l_password_field;
    ProgressBar progressBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        l_email_field = (EditText) findViewById(R.id.l_email_field);
        l_password_field = (EditText) findViewById(R.id.l_password_field);
        progressBar = (ProgressBar) findViewById(R.id.progressbar);

        mAuth = FirebaseAuth.getInstance();

        findViewById(R.id.TextViewSignUp).setOnClickListener(this);
        findViewById(R.id.login_btn).setOnClickListener(this);

    }

    private void userLogin(){

        String email = l_email_field.getText().toString().trim();
        String password = l_password_field.getText().toString().trim();

        if(email.isEmpty()){
            l_email_field.setError("Email is required");
            l_email_field.requestFocus();

            return;
        }

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            l_email_field.setError("Please enter a valid email");
            l_email_field.requestFocus();
            return;
        }

        if(password.length()<6){
            l_password_field.setError("Minimum length of password should be 6");
            l_password_field.requestFocus();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                progressBar.setVisibility(View.GONE);
                if(task.isSuccessful()) {
                    Intent intent = new Intent(MainActivity.this, Home.class );
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }else {
                    Toast.makeText(getApplicationContext(),task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.TextViewSignUp:

                startActivity(new Intent(this, SignUpActivity.class));

                break;

            case R.id.login_btn:
                userLogin();
                return;


        }

    }
}
